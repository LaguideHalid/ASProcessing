﻿CREATE TABLE [dbo].[AdventureWorksDWBuildVersion] (
    [DBVersion]   NVARCHAR (50) NULL,
    [VersionDate] DATETIME      NULL
);


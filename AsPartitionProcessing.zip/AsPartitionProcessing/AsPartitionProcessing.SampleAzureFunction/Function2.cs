using System.Collections.Generic;

using System.Net.Http;
using System.Security;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AsPartitionProcessing.SampleAzureFunction
{
    public static class Function2
    {

        private static string _modelConfigurationIDs;
        [FunctionName("ASPartition")]
        public static async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)]HttpRequestMessage req, TraceWriter log)
        {
            log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) started at: {DateTime.Now}");

            try
            {
                /* read from ASPP_ConfigurationLoggingDB */
                List<ModelConfiguration> modelsConfig = InitializeFromDatabase();

                /* loop through Model Config */
                foreach (ModelConfiguration modelConfig in modelsConfig)
                {
                    /* grab user/pw for AzureAS authentication */
                    ;
                    String azure_AppID = "b020b646-3a8c-4077-a7ca-234fd4829417";// System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_AzureAS_SvcPrincipal_AppID");
                    String azure_AppKey = "Pu2Fr3d25uj0e8uoLi1W_~ZK~.cbuFUR.b"; //System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_AzureAS_SvcPrincipal_AppKey");

                    /* apparently you can do it this way as well */
                    modelConfig.UserName = azure_AppID;
                    modelConfig.Password = azure_AppKey;

                    /* perform processing */
                    PartitionProcessor.PerformProcessing(modelConfig, ConfigDatabaseHelper.LogMessage);
                }
            }
            catch (Exception e)
            {
                log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) exception: {e.ToString()}");
            }

            log.Info($"C# Timer trigger function (fAsPartitionProcessingTimer) finished at: {DateTime.Now}");

            return new OkObjectResult("code executed successfully");
        }


        public static List<ModelConfiguration> InitializeFromDatabase()
        {
            ConfigDatabaseConnectionInfo connectionInfo = new ConfigDatabaseConnectionInfo();

            connectionInfo.Server = "jhl.database.windows.net"; //System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_connstr_ASPP_ConfigurationLogging_SERVER");
            connectionInfo.Database = "ASPP_ConfigurationLogging";//System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_connstr_ASPP_ConfigurationLogging_DB");
            connectionInfo.UserName = "VM-Admin"; //System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_connstr_ASPP_ConfigurationLogging_USER");
            connectionInfo.Password = "Lidou_123";//System.Environment.GetEnvironmentVariable("CUSTOMCONNSTR_connstr_ASPP_ConfigurationLogging_PW");

            return ConfigDatabaseHelper.ReadConfig(connectionInfo, _modelConfigurationIDs);
        }
    }
}
